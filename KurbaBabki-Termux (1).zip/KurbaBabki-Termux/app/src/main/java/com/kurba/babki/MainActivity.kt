package com.kurba.babki

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

@Entity(tableName = "operations")
data class Operation(@PrimaryKey(autoGenerate = true) val id: Long = 0, val type: String, val amount: Double, val category: String, val date: Long, val comment: String = "")
@Entity(tableName = "categories", primaryKeys = ["name", "type"])
data class Category(val name: String, val type: String, val custom: Boolean = true)
@Dao interface FinanceDao {
 @Query("SELECT * FROM operations ORDER BY date DESC, id DESC") fun operations(): Flow<List<Operation>>
 @Insert suspend fun insert(o: Operation): Long
 @Update suspend fun update(o: Operation)
 @Delete suspend fun delete(o: Operation)
 @Query("DELETE FROM operations") suspend fun clearOperations()
 @Query("SELECT * FROM categories ORDER BY type, name") fun categories(): Flow<List<Category>>
 @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertCategories(c: List<Category>)
 @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertCategory(c: Category)
 @Query("DELETE FROM categories WHERE name=:name AND type=:type") suspend fun deleteCategory(name:String,type:String)
}
@Database(entities=[Operation::class,Category::class],version=1,exportSchema=false)
abstract class AppDb: RoomDatabase(){ abstract fun dao(): FinanceDao
 companion object { @Volatile private var I: AppDb?=null; fun get(c:Context)=I?:synchronized(this){I?:Room.databaseBuilder(c.applicationContext,AppDb::class.java,"kurba_babki.db").build().also{I=it}} }
}

class Settings(context: Context){
 private val p=context.getSharedPreferences("settings",Context.MODE_PRIVATE)
 var currency:String get()=p.getString("currency","₽")!!; set(v)=p.edit().putString("currency",v).apply()
 var theme:String get()=p.getString("theme","system")!!; set(v)=p.edit().putString("theme",v).apply()
 var pinHash:String get()=p.getString("pin","")!!; set(v)=p.edit().putString("pin",v).apply()
 var biometric:Boolean get()=p.getBoolean("bio",false); set(v)=p.edit().putBoolean("bio",v).apply()
}
fun hashPin(pin:String):String { val salt="KurbaBabkiFixedSalt".toByteArray(); val spec=PBEKeySpec(pin.toCharArray(),salt,12000,256); val b=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded; return b.joinToString(""){ "%02x".format(it) } }
fun money(v:Double,c:String)=String.format(Locale.US,"%,.2f %s",v,c).replace(","," ")
fun dayStart(t:Long)=Calendar.getInstance().apply{timeInMillis=t;set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis

enum class Period(val label:String){TODAY("Сегодня"),WEEK("Неделя"),MONTH("Месяц"),YEAR("Год"),ALL("Всё время")}
class VM(val dao:FinanceDao):ViewModel(){
 val ops=dao.operations().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList()); val cats=dao.categories().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 init{viewModelScope.launch{dao.insertCategories(listOf("Еда","Продукты","Транспорт","Жильё","Коммунальные услуги","Покупки","Развлечения","Здоровье","Связь","Подписки","Другое").map{Category(it,"expense",false)}+listOf("Зарплата","Подработка","Подарок","Инвестиции","Другое").map{Category(it,"income",false)})}}
 fun add(type:String,amount:Double,cat:String,date:Long,comment:String)=viewModelScope.launch{dao.insert(Operation(type=type,amount=amount,category=cat,date=date,comment=comment))}
 fun update(o:Operation)=viewModelScope.launch{dao.update(o)}; fun delete(o:Operation)=viewModelScope.launch{dao.delete(o)}
 fun addCat(c:Category)=viewModelScope.launch{dao.insertCategory(c)}; fun delCat(c:Category)=viewModelScope.launch{if(c.custom)dao.deleteCategory(c.name,c.type)}
 fun restore(list:List<Operation>,cats:List<Category>)=viewModelScope.launch{dao.clearOperations();list.forEach{dao.insert(it)};cats.forEach{dao.insertCategory(it)}}
}
class VMF(private val dao:FinanceDao):ViewModelProvider.Factory{override fun <T:ViewModel> create(c:Class<T>):T=VM(dao) as T}

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val s=Settings(this);setContent{App(s)}}
}

@Composable fun App(settings:Settings){
 val ctx=LocalContext.current; val vm:VM= androidx.lifecycle.viewmodel.compose.viewModel(factory=VMF(AppDb.get(ctx).dao())); val ops by vm.ops.collectAsStateWithLifecycle(); val cats by vm.cats.collectAsStateWithLifecycle(); var tab by remember{mutableIntStateOf(0)}; var period by remember{mutableStateOf(Period.MONTH)}; var locked by remember{mutableStateOf(settings.pinHash.isNotBlank()||settings.biometric)}
 if(locked){LockScreen(settings){locked=false};return}
 val dark=when(settings.theme){"dark"->true;"light"->false;else->isSystemInDarkTheme()}
 MaterialTheme(colorScheme=if(dark) darkColorScheme() else lightColorScheme(), typography=Typography(bodyLarge=LocalTextStyle.current.copy(fontSize=16.sp))){
  Scaffold(bottomBar={NavigationBar{listOf("Главная","История","Статистика","Настройки").forEachIndexed{i,t->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(listOf(Icons.Default.Home,Icons.Default.List,Icons.Default.PieChart,Icons.Default.Settings)[i],null)},label={Text(t)})}}){pad->Box(Modifier.padding(pad)){when(tab){0->Home(vm,ops,cats,settings,period,{period=it});1->History(vm,ops,cats,settings);2->Stats(ops,settings,period);3->SettingsScreen(settings,ops,cats,vm,{locked=true})}}}}
 }
}

@Composable fun Header(title:String,sub:String=""){Column(Modifier.padding(horizontal=20.dp,vertical=14.dp)){Text(title,fontSize=28.sp,fontWeight=FontWeight.Bold);if(sub.isNotBlank())Text(sub,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun PeriodRow(p:Period,on:(Period)->Unit){Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Period.values().forEach{x->FilterChip(selected=p==x,onClick={on(x)},label={Text(x.label)},modifier=Modifier.height(36.dp)))}}
fun filtered(ops:List<Operation>,p:Period):List<Operation>{if(p==Period.ALL)return ops;val now=Calendar.getInstance();val start=Calendar.getInstance();when(p){Period.TODAY->start.timeInMillis=dayStart(now.timeInMillis);Period.WEEK->start.add(Calendar.DAY_OF_YEAR,-6);Period.MONTH->start.set(Calendar.DAY_OF_MONTH,1);Period.YEAR->start.set(Calendar.DAY_OF_YEAR,1);else->Unit};return ops.filter{it.date>=start.timeInMillis}}

@Composable fun Home(vm:VM,ops:List<Operation>,cats:List<Category>,s:Settings,p:Period,onP:(Period)->Unit){var add by remember{mutableStateOf(false)};val list=filtered(ops,p);val income=list.filter{it.type=="income"}.sumOf{it.amount};val expense=list.filter{it.type=="expense"}.sumOf{it.amount};LazyColumn{item{Header("Курба бабки","Ваши деньги под контролем")};item{PeriodRow(p,onP)};item{Card(Modifier.padding(16.dp).fillMaxWidth(),shape=RoundedCornerShape(28.dp)){Column(Modifier.padding(22.dp)){Text("Баланс",color=MaterialTheme.colorScheme.onSurfaceVariant);Text(money(income-expense,s.currency),fontSize=32.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Stat("Доходы",money(income,s.currency));Stat("Расходы",money(expense,s.currency))}}}};item{Row(Modifier.padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically){Text("Последние операции",fontSize=20.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));TextButton(onClick={}){Text("")}}};items(list.take(8)){OpRow(it,s){}};item{Spacer(Modifier.height(90.dp))}};FloatingActionButton(onClick={add=true},modifier=Modifier.padding(20.dp).fillMaxWidth().height(58.dp)){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Добавить операцию",fontWeight=FontWeight.Bold)};if(add)OperationDialog(vm,cats,s){add=false}}
@Composable fun Stat(label:String,value:String){Column{Text(label,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(value,fontWeight=FontWeight.SemiBold)}}

@Composable fun OpRow(o:Operation,s:Settings,onClick:()->Unit,onDelete:(()->Unit)?=null){ListItem(headlineContent={Text(o.category,fontWeight=FontWeight.SemiBold)},supportingContent={Text(SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(Date(o.date))+(if(o.comment.isNotBlank())" • ${o.comment}" else ""))},leadingContent={Surface(shape=RoundedCornerShape(12.dp)){Icon(if(o.type=="income")Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,null,Modifier.padding(10.dp))}},trailingContent={Row(verticalAlignment=Alignment.CenterVertically){Text((if(o.type=="income")"+" else "−")+money(o.amount,s.currency),fontWeight=FontWeight.Bold);if(onDelete!=null)IconButton(onClick=onDelete){Icon(Icons.Default.Delete,null)}}},modifier=Modifier.clickable{onClick()})}

@Composable fun OperationDialog(vm:VM,cats:List<Category>,s:Settings,onDone:()->Unit,existing:Operation?=null){var type by remember{mutableStateOf(existing?.type?:"expense")};var amount by remember{mutableStateOf(existing?.amount?.toString()?:(""))};var cat by remember{mutableStateOf(existing?.category?:(cats.firstOrNull{it.type==type}?.name?:"Другое"))};var comment by remember{mutableStateOf(existing?.comment?:"")};AlertDialog(onDismissRequest=onDone,title={Text(if(existing==null)"Новая операция" else "Изменить операцию")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth()){FilterChip(selected=type=="expense",onClick={type="expense"},label={Text("Расход")});Spacer(Modifier.width(8.dp));FilterChip(selected=type=="income",onClick={type="income"},label={Text("Доход")})};OutlinedTextField(amount,{amount=it},label={Text("Сумма (${s.currency})")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);var menu by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={menu=true},modifier=Modifier.fillMaxWidth()){Text(cat)};DropdownMenu(expanded=menu,onDismissRequest={menu=false}){cats.filter{it.type==type}.forEach{x->DropdownMenuItem(text={Text(x.name)},onClick={cat=x.name;menu=false})}}};OutlinedTextField(comment,{comment=it},label={Text("Комментарий (необязательно)")},singleLine=true)}},confirmButton={Button(onClick={val a=amount.replace(',','.').toDoubleOrNull();if(a!=null&&a>0){if(existing==null)vm.add(type,a,cat,System.currentTimeMillis(),comment) else vm.update(existing.copy(type=type,amount=a,category=cat,comment=comment));onDone()}}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDone){Text("Отмена")}})}

@Composable fun History(vm:VM,ops:List<Operation>,cats:List<Category>,s:Settings){var q by remember{mutableStateOf("")};var type by remember{mutableStateOf("all")};var edit by remember{mutableStateOf<Operation?>(null)};var del by remember{mutableStateOf<Operation?>(null)};Column{Header("История","Все операции");OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("Поиск")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true);Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(type=="all",{type="all"},{Text("Все")});FilterChip(type=="income",{type="income"},{Text("Доходы")});FilterChip(type=="expense",{type="expense"},{Text("Расходы")})};LazyColumn{items(ops.filter{(type=="all"||it.type==type)&&(q.isBlank()||it.category.contains(q,true)||it.comment.contains(q,true))}){o->OpRow(o,s,{edit=o},{del=o});Divider();}}};if(edit!=null)OperationDialog(vm,cats,s,{edit=null},edit);if(del!=null)AlertDialog(onDismissRequest={del=null},title={Text("Удалить операцию?")},text={Text("Это действие нельзя отменить.")},confirmButton={Button(onClick={vm.delete(del!!);del=null}){Text("Удалить")}},dismissButton={TextButton(onClick={del=null}){Text("Отмена")}})} }

@Composable fun Stats(ops:List<Operation>,s:Settings,p:Period){val l=filtered(ops,p);val income=l.filter{it.type=="income"}.sumOf{it.amount};val expense=l.filter{it.type=="expense"}.sumOf{it.amount};val by=l.filter{it.type=="expense"}.groupBy{it.category}.mapValues{it.value.sumOf{v->v.amount}}.toList().sortedByDescending{it.second};Column{Header("Статистика",p.label);LazyColumn(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){MetricCard("Доходы",income,s.currency);MetricCard("Расходы",expense,s.currency)}};item{MetricCard("Баланс",income-expense,s.currency)};item{Text("Расходы по категориям",fontSize=20.sp,fontWeight=FontWeight.Bold)};items(by){(name,v)->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Row{Text(name);Spacer(Modifier.weight(1f));Text(money(v,s.currency),fontWeight=FontWeight.Bold)};LinearProgressIndicator(progress={(if(expense==0.0)0.0 else (v/expense)).toFloat()},Modifier.fillMaxWidth().padding(top=8.dp))}}};item{Text("Динамика",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Встроенная статистика автоматически пересчитывается по выбранному периоду. Для точного анализа по дням используйте историю операций.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}
@Composable fun MetricCard(t:String,v:Double,c:String)=Card(Modifier.weight(1f)){Column(Modifier.padding(16.dp)){Text(t,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(money(v,c),fontWeight=FontWeight.Bold,fontSize=18.sp)}}

@Composable fun SettingsScreen(s:Settings,ops:List<Operation>,cats:List<Category>,vm:VM,onLock:()->Unit){val ctx=LocalContext.current;var currency by remember{mutableStateOf(s.currency)};var theme by remember{mutableStateOf(s.theme)};var pin by remember{mutableStateOf(s.pinHash.isNotBlank())};var bio by remember{mutableStateOf(s.biometric)};var newCat by remember{mutableStateOf("")};var catType by remember{mutableStateOf("expense")};var showPin by remember{mutableStateOf(false)};var backup by remember{mutableStateOf(false)};Column{Header("Настройки");LazyColumn{item{ListItem(headlineContent={Text("Валюта")},trailingContent={Row{FilterChip(currency=="₽",{currency="₽";s.currency="₽"},{Text("₽")});Spacer(Modifier.width(8.dp));FilterChip(currency=="$",{currency="$";s.currency="$"},{Text("$")})}})};item{ListItem(headlineContent={Text("Тема")},supportingContent={Text("Светлая / тёмная / системная")},trailingContent={Text(theme.replaceFirstChar{it.uppercase()})},modifier=Modifier.clickable{theme=when(theme){"system"->"light";"light"->"dark";else->"system"};s.theme=theme})};item{HorizontalDivider()};item{ListItem(headlineContent={Text("PIN-код")},supportingContent={Text(if(pin)"Защита включена" else "Выключено")},trailingContent={Switch(pin,{pin=it;if(it)showPin=true else{s.pinHash=""}}))};item{ListItem(headlineContent={Text("Биометрия")},supportingContent={Text("Отпечаток или распознавание лица")},trailingContent={Switch(bio,{bio=it;s.biometric=it})})};item{ListItem(headlineContent={Text("Резервная копия")},supportingContent={Text("Экспорт и восстановление данных")},trailingContent={Icon(Icons.Default.Backup,null)},modifier=Modifier.clickable{backup=true})};item{Text("Категории",fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(16.dp))};item{Row(Modifier.padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(newCat,{newCat=it},Modifier.weight(1f),label={Text("Новая категория")});Spacer(Modifier.width(8.dp));IconButton(onClick={if(newCat.isNotBlank()){vm.addCat(Category(newCat.trim(),catType,true));newCat=""}}){Icon(Icons.Default.Add,null)}}};item{Row(Modifier.padding(horizontal=16.dp)){FilterChip(catType=="expense",{catType="expense"},{Text("Расходы")});Spacer(Modifier.width(8.dp));FilterChip(catType=="income",{catType="income"},{Text("Доходы")})}};items(cats.filter{it.custom}){c->ListItem(headlineContent={Text(c.name)},trailingContent={IconButton(onClick={vm.delCat(c)}){Icon(Icons.Default.Delete,null)}})};item{Button(onClick=onLock,Modifier.padding(16.dp).fillMaxWidth()){Text("Заблокировать сейчас")};Text("Курба бабки • версия 1.0",modifier=Modifier.padding(16.dp),color=MaterialTheme.colorScheme.onSurfaceVariant)}}};if(showPin)PinDialog(s,{showPin=false;pin=true});if(backup)BackupDialog(vm,ops,cats,s,{backup=false})}

@Composable fun PinDialog(s:Settings,onDone:()->Unit){var p by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDone,title={Text("Создайте PIN")},text={OutlinedTextField(p,{if(it.length<=6)p=it},label={Text("4–6 цифр")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))},confirmButton={Button(onClick={if(p.length in 4..6){s.pinHash=hashPin(p);onDone()}}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDone){Text("Отмена")}})}

@Composable fun LockScreen(s:Settings,unlock:()->Unit){val ctx=LocalContext.current;var p by remember{mutableStateOf("")};var err by remember{mutableStateOf(false)};Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.Lock,null,Modifier.size(54.dp));Text("Курба бабки",fontSize=30.sp,fontWeight=FontWeight.Bold);Text("Введите PIN для доступа",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(24.dp));OutlinedTextField(p,{if(it.length<=6)p=it},label={Text("PIN")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword));if(err)Text("Неверный PIN",color=MaterialTheme.colorScheme.error);Spacer(Modifier.height(12.dp));Button(onClick={if(hashPin(p)==s.pinHash)unlock() else err=true}){Text("Открыть")};if(s.biometric){TextButton(onClick={biometric(ctx as Activity,unlock)}){Text("Использовать биометрию")}}}}
fun biometric(a:Activity,ok:()->Unit){val executor=a.mainExecutor;val p=BiometricPrompt(a,executor,object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){ok()}});p.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("Курба бабки").setSubtitle("Подтвердите личность").setNegativeButtonText("Отмена").build())}

@Composable fun BackupDialog(vm:VM,ops:List<Operation>,cats:List<Category>,s:Settings,onDone:()->Unit){
 val ctx=LocalContext.current
 val create=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
  if(uri!=null){val root=JSONObject();root.put("version",1);root.put("currency",s.currency);val a=JSONArray();ops.forEach{o->a.put(JSONObject().apply{put("id",o.id);put("type",o.type);put("amount",o.amount);put("category",o.category);put("date",o.date);put("comment",o.comment)})};root.put("operations",a);val c=JSONArray();cats.forEach{x->c.put(JSONObject().apply{put("name",x.name);put("type",x.type);put("custom",x.custom)})};root.put("categories",c);ctx.contentResolver.openOutputStream(uri)?.use{it.write(root.toString(2).toByteArray())}}
 }
 val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
  if(uri!=null){runCatching{val text=ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText();val root=JSONObject(text);val a=root.getJSONArray("operations");val list=buildList{for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Operation(o.optLong("id",0),o.getString("type"),o.getDouble("amount"),o.getString("category"),o.getLong("date"),o.optString("comment")))}};val c=root.optJSONArray("categories");val cl=buildList{if(c!=null)for(i in 0 until c.length()){val x=c.getJSONObject(i);add(Category(x.getString("name"),x.getString("type"),x.optBoolean("custom",true)))}};vm.restore(list,cl);s.currency=root.optString("currency",s.currency)}}}
 AlertDialog(onDismissRequest=onDone,title={Text("Резервная копия")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Сохраните все операции и категории в JSON-файл. Файл можно перенести на другое устройство и восстановить.");Button(onClick={create.launch("kurba_babki_backup.json")},modifier=Modifier.fillMaxWidth()){Text("Создать резервную копию")};OutlinedButton(onClick={restore.launch(arrayOf("application/json"))},modifier=Modifier.fillMaxWidth()){Text("Восстановить из файла")};Text("Резервная копия не требует интернета.",color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={TextButton(onClick=onDone){Text("Готово")}})
}
